import type { ResumeExperienceViewModel } from "@/lib/resume-types"
import { ResumeSection } from "./resume-section"
import { MapPin } from "lucide-react"

type ExperienceItemProps = {
  experience: ResumeExperienceViewModel
  isLast: boolean
}

function ExperienceItem({ experience, isLast }: ExperienceItemProps) {
  const { title, company, location, workMode, startDate, endDate, current, bullets } =
    experience

  const dateRange = current ? `${startDate} — Present` : `${startDate} — ${endDate}`

  const locationLabel = [location, workMode].filter(Boolean).join(" · ")

  return (
    <div
      className={`group py-4 transition-colors hover:bg-neutral-50/50 ${
        isLast ? "" : "border-b border-neutral-100"
      }`}
    >
      <div className="flex items-start justify-between gap-4 px-0">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <span className="text-sm font-semibold text-neutral-900">{title}</span>
            <span className="text-sm text-neutral-500">{company}</span>
          </div>
          {locationLabel && (
            <div className="mt-0.5 flex items-center gap-1 text-xs text-neutral-400">
              <MapPin className="h-3 w-3 shrink-0" />
              {locationLabel}
            </div>
          )}
        </div>
        <span className="shrink-0 whitespace-nowrap text-xs tabular-nums text-neutral-400">
          {dateRange}
        </span>
      </div>

      {bullets.length > 0 && (
        <ul className="mt-2.5 space-y-1.5">
          {bullets.map((bullet, i) => (
            <li key={i} className="flex gap-2 text-sm leading-relaxed text-neutral-600">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-neutral-300" />
              <span>{bullet}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

type Props = {
  experiences: ResumeExperienceViewModel[]
}

export function ExperiencePanel({ experiences }: Props) {
  if (experiences.length === 0) return null

  return (
    <ResumeSection title="Experience" scrollable className="flex-1">
      <div className="-mx-4 -my-4">
        {experiences.map((exp, i) => (
          <div key={exp.id} className="px-4">
            <ExperienceItem experience={exp} isLast={i === experiences.length - 1} />
          </div>
        ))}
      </div>
    </ResumeSection>
  )
}
