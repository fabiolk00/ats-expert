import { ResumeSection } from "./resume-section"

type Props = {
  summary?: string
}

export function ProfessionalSummaryPanel({ summary }: Props) {
  if (!summary) return null

  return (
    <ResumeSection title="Professional Summary">
      <p className="text-sm leading-relaxed text-neutral-600">{summary}</p>
    </ResumeSection>
  )
}
