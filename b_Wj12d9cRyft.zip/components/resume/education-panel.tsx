import type { ResumeEducationViewModel } from "@/lib/resume-types"
import { ResumeSection } from "./resume-section"

type Props = {
  education: ResumeEducationViewModel[]
}

export function EducationPanel({ education }: Props) {
  if (education.length === 0) return null

  return (
    <ResumeSection title="Education">
      <div className="space-y-3">
        {education.map((item, i) => (
          <div key={item.id}>
            <p className="text-sm font-medium text-neutral-800">{item.degree}</p>
            <p className="text-xs text-neutral-400">
              {item.institution}
              {item.year && ` · ${item.year}`}
            </p>
            {i < education.length - 1 && (
              <div className="mt-3 border-t border-neutral-100" />
            )}
          </div>
        ))}
      </div>
    </ResumeSection>
  )
}
