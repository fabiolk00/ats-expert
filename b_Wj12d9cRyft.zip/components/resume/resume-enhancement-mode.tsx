"use client"

import { useState } from "react"
import { ArrowLeft, Sparkles, Loader2, CheckCircle2, ShieldCheck, Zap, Target } from "lucide-react"
import { cn } from "@/lib/utils"

type GenerationMode = "ats" | "job"
type EnhancementIntent = "ats" | "target_job"

type GenerationCopy = {
  buttonIdle: string
  buttonRunning: string
}

type Props = {
  targetJobDescription: string
  onTargetJobDescriptionChange: (value: string) => void
  generationMode: GenerationMode
  generationCopy: GenerationCopy
  isRunning: boolean
  disabled: boolean
  currentCredits: number
  onGenerate: () => void
  onBack: () => void
}

const VALUE_ITEMS = [
  "Currículo mais claro e compatível com ATS",
  "Resumo profissional mais direto",
  "Experiências reescritas em bullets fortes",
  "Keywords alinhadas ao modo escolhido",
  "Versão pronta para comparar e exportar",
  "Seu currículo base continua preservado",
]

export function ResumeEnhancementMode({
  targetJobDescription,
  onTargetJobDescriptionChange,
  generationMode,
  generationCopy,
  isRunning,
  disabled,
  currentCredits,
  onGenerate,
  onBack,
}: Props) {
  const [enhancementIntent, setEnhancementIntent] = useState<EnhancementIntent>(
    targetJobDescription.trim().length > 0 ? "target_job" : "ats"
  )
  const [validationError, setValidationError] = useState("")

  function handleSelectAtsIntent() {
    setEnhancementIntent("ats")
    onTargetJobDescriptionChange("")
    setValidationError("")
  }

  function handleSelectTargetJobIntent() {
    setEnhancementIntent("target_job")
    setValidationError("")
  }

  function handleTextareaChange(value: string) {
    onTargetJobDescriptionChange(value)
    if (value.trim().length > 0) {
      setEnhancementIntent("target_job")
      setValidationError("")
    }
  }

  function handleGenerate() {
    if (enhancementIntent === "target_job" && targetJobDescription.trim().length === 0) {
      setValidationError("Cole a descrição da vaga para adaptar seu currículo.")
      return
    }
    setValidationError("")
    onGenerate()
  }

  const modeBadgeLabel =
    enhancementIntent === "target_job" ? "Adaptação para vaga" : "Melhoria ATS geral"

  return (
    <div className="flex h-screen flex-col bg-white">
      {/* Top bar */}
      <div className="flex items-center justify-between border-b border-neutral-200 px-8 py-4">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-medium text-neutral-500 transition-colors hover:text-neutral-900"
        >
          <ArrowLeft className="h-4 w-4" />
          Voltar ao perfil
        </button>

        <div className="flex items-center gap-3">
          <span className="rounded-full border border-neutral-200 bg-neutral-50 px-3 py-1 text-xs font-medium text-neutral-600">
            Modo:{" "}
            <span className="font-semibold text-neutral-900">{modeBadgeLabel}</span>
          </span>
          <span className="text-xs text-neutral-400">
            {currentCredits} crédito{currentCredits !== 1 ? "s" : ""} disponível{currentCredits !== 1 ? "is" : ""}
          </span>
        </div>
      </div>

      {/* Main workspace */}
      <div className="mx-auto flex w-full max-w-6xl flex-1 gap-10 overflow-hidden px-8 py-8">
        {/* Left — action area */}
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="mb-5">
            <h2 className="text-lg font-semibold text-neutral-900">
              Otimize seu currículo para passar melhor em ATS
            </h2>
            <p className="mt-1 text-sm leading-relaxed text-neutral-500">
              Escolha como você quer gerar sua próxima versão otimizada.
            </p>
          </div>

          {/* Intent selector cards */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={handleSelectAtsIntent}
              disabled={isRunning}
              className={cn(
                "rounded-xl border p-4 text-left transition hover:border-neutral-300 disabled:cursor-not-allowed disabled:opacity-60",
                enhancementIntent === "ats"
                  ? "border-neutral-900 bg-neutral-50 ring-1 ring-neutral-900"
                  : "border-neutral-200 bg-white"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-neutral-100">
                    <Zap className="h-3.5 w-3.5 text-neutral-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-neutral-950">Melhorar para ATS</p>
                    <p className="text-xs text-neutral-500">Sem vaga específica</p>
                  </div>
                </div>
                {enhancementIntent === "ats" && (
                  <span className="shrink-0 rounded-full bg-neutral-900 px-2 py-0.5 text-[10px] font-medium text-white">
                    Selecionado
                  </span>
                )}
              </div>
              <p className="mt-3 text-sm leading-relaxed text-neutral-600">
                Reestrutura seu currículo para ficar mais claro, objetivo e compatível com sistemas ATS.
              </p>
            </button>

            <button
              type="button"
              onClick={handleSelectTargetJobIntent}
              disabled={isRunning}
              className={cn(
                "rounded-xl border p-4 text-left transition hover:border-neutral-300 disabled:cursor-not-allowed disabled:opacity-60",
                enhancementIntent === "target_job"
                  ? "border-neutral-900 bg-neutral-50 ring-1 ring-neutral-900"
                  : "border-neutral-200 bg-white"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-neutral-100">
                    <Target className="h-3.5 w-3.5 text-neutral-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-neutral-950">Adaptar para vaga</p>
                    <p className="text-xs text-neutral-500">Com descrição da vaga</p>
                  </div>
                </div>
                {enhancementIntent === "target_job" && (
                  <span className="shrink-0 rounded-full bg-neutral-900 px-2 py-0.5 text-[10px] font-medium text-white">
                    Selecionado
                  </span>
                )}
              </div>
              <p className="mt-3 text-sm leading-relaxed text-neutral-600">
                Usa a descrição da vaga para priorizar keywords, requisitos e experiências mais relevantes.
              </p>
            </button>
          </div>

          {/* Conditional content area */}
          <div className="mt-5 flex flex-1 flex-col">
            {enhancementIntent === "ats" ? (
              <div className="rounded-xl border border-neutral-200 bg-neutral-50 p-5">
                <p className="text-sm font-semibold text-neutral-900">Melhoria ATS geral</p>
                <p className="mt-1 text-xs font-medium text-neutral-500">
                  Ideal quando você ainda não tem uma vaga específica.
                </p>
                <p className="mt-3 text-sm leading-relaxed text-neutral-600">
                  A IA vai melhorar estrutura, clareza, resumo profissional, bullets de
                  experiência e compatibilidade com sistemas ATS — sem precisar de uma vaga alvo.
                </p>
              </div>
            ) : (
              <div className="flex flex-1 flex-col">
                <label
                  htmlFor="target-job-description"
                  className="mb-2 block text-xs font-semibold uppercase tracking-wide text-neutral-400"
                >
                  Descrição da vaga
                </label>
                <p className="mb-2.5 text-xs leading-relaxed text-neutral-500">
                  Cole a descrição completa da vaga para a IA adaptar seu currículo com base nos requisitos reais.
                </p>
                <textarea
                  id="target-job-description"
                  value={targetJobDescription}
                  onChange={(e) => handleTextareaChange(e.target.value)}
                  placeholder="Cole aqui responsabilidades, requisitos, qualificações, stack, senioridade e qualquer detalhe importante da vaga..."
                  className={cn(
                    "min-h-[260px] flex-1 resize-none rounded-lg border bg-neutral-50 px-4 py-3 text-sm leading-relaxed text-neutral-800 placeholder-neutral-400 outline-none transition-colors focus:bg-white",
                    validationError
                      ? "border-red-300 focus:border-red-400"
                      : "border-neutral-200 focus:border-neutral-400"
                  )}
                  disabled={isRunning}
                />
                {validationError && (
                  <p className="mt-1.5 text-xs text-red-500">{validationError}</p>
                )}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="mt-5 flex flex-col gap-3">
            {currentCredits < 1 && (
              <p className="flex items-center gap-1.5 text-xs text-amber-600">
                <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
                Você precisa de pelo menos 1 crédito para gerar uma versão otimizada.
              </p>
            )}

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleGenerate}
                disabled={disabled || isRunning}
                className="flex h-10 items-center gap-2 rounded-lg bg-neutral-900 px-5 text-sm font-medium text-white transition-colors hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isRunning ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {generationCopy.buttonRunning}
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    {enhancementIntent === "ats"
                      ? "Melhorar para ATS (1 crédito)"
                      : "Adaptar para esta vaga (1 crédito)"}
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onBack}
                disabled={isRunning}
                className="flex h-10 items-center gap-2 rounded-lg border border-neutral-200 px-4 text-sm font-medium text-neutral-600 transition-colors hover:border-neutral-300 hover:bg-neutral-50 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Voltar ao perfil
              </button>
            </div>
          </div>
        </div>

        {/* Right — value panel */}
        <aside className="w-72 shrink-0">
          <div className="rounded-xl border border-neutral-200 bg-white p-6">
            <h3 className="text-sm font-semibold text-neutral-900">O que você recebe</h3>
            <p className="mt-1 text-xs leading-relaxed text-neutral-500">
              Uma nova versão otimizada sem sobrescrever seu currículo base.
            </p>

            <ul className="mt-5 space-y-3">
              {VALUE_ITEMS.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-px h-4 w-4 shrink-0 text-emerald-600" />
                  <span className="text-sm leading-relaxed text-neutral-700">{item}</span>
                </li>
              ))}
            </ul>

            <div className="mt-6 rounded-lg border border-emerald-200 bg-emerald-50 p-3">
              <p className="text-sm font-medium text-emerald-900">Seguro para testar</p>
              <p className="mt-1 text-xs leading-relaxed text-emerald-700">
                Seu currículo base continua preservado. Você compara a nova versão antes de exportar.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  )
}
