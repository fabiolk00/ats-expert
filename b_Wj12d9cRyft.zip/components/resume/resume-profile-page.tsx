"use client"

import { useState, useMemo } from "react"
import type { ResumeProfileViewModel } from "@/lib/resume-types"
import { ResumeProfileHeader } from "./resume-profile-header"
import { ProfessionalSummaryPanel } from "./professional-summary-panel"
import { ExperiencePanel } from "./experience-panel"
import { SkillsPanel } from "./skills-panel"
import { EducationPanel } from "./education-panel"
import { CertificationsPanel } from "./certifications-panel"
import { ResumeEnhancementMode } from "./resume-enhancement-mode"

type ResumeProfileViewMode = "profile" | "enhancement"
type GenerationMode = "ats" | "job"

type Props = {
  profile: ResumeProfileViewModel
}

export function ResumeProfilePage({ profile }: Props) {
  const [viewMode, setViewMode] = useState<ResumeProfileViewMode>("profile")
  const [targetJobDescription, setTargetJobDescription] = useState("")
  const [isRunningAtsEnhancement, setIsRunningAtsEnhancement] = useState(false)
  // In a real integration this would come from the user's account context
  const currentCredits = 3

  const generationMode: GenerationMode =
    targetJobDescription.trim().length > 0 ? "job" : "ats"

  const generationCopy = useMemo(() => {
    if (generationMode === "job") {
      return {
        buttonIdle: "Adaptar para esta vaga (1 crédito)",
        buttonRunning: "Adaptando currículo...",
      }
    }
    return {
      buttonIdle: "Melhorar para ATS (1 crédito)",
      buttonRunning: "Melhorando currículo...",
    }
  }, [generationMode])

  const setupGenerationButtonDisabled =
    isRunningAtsEnhancement || currentCredits < 1

  async function handleSetupGeneration() {
    if (setupGenerationButtonDisabled) return
    setIsRunningAtsEnhancement(true)
    try {
      // Reuse existing endpoint — wire to real API call here
      await new Promise<void>((resolve) => setTimeout(resolve, 2000))
    } finally {
      setIsRunningAtsEnhancement(false)
    }
  }

  function handleDownloadPdf() {
    console.log("[v0] Download PDF triggered")
  }

  if (viewMode === "enhancement") {
    return (
      <ResumeEnhancementMode
        targetJobDescription={targetJobDescription}
        onTargetJobDescriptionChange={setTargetJobDescription}
        generationMode={generationMode}
        generationCopy={generationCopy}
        isRunning={isRunningAtsEnhancement}
        disabled={setupGenerationButtonDisabled}
        currentCredits={currentCredits}
        onGenerate={() => void handleSetupGeneration()}
        onBack={() => setViewMode("profile")}
      />
    )
  }

  return (
    <main className="h-screen overflow-hidden bg-white">
      <div className="mx-auto flex h-full max-w-7xl flex-col px-6 py-5">
        <ResumeProfileHeader
          profile={profile}
          onOpenEnhancement={() => setViewMode("enhancement")}
          onDownloadPdf={handleDownloadPdf}
        />

        {/* Two-column content grid */}
        <div className="grid min-h-0 flex-1 grid-cols-[minmax(0,1.7fr)_minmax(320px,0.9fr)] gap-5">
          {/* Left column — Primary reading area */}
          <section className="flex min-h-0 flex-col gap-5">
            <ProfessionalSummaryPanel summary={profile.summary} />
            <ExperiencePanel experiences={profile.experiences} />
          </section>

          {/* Right column — Supporting information */}
          <aside className="flex min-h-0 flex-col gap-5 overflow-y-auto pb-1">
            <SkillsPanel skillGroups={profile.skillGroups} />
            <EducationPanel education={profile.education} />
            <CertificationsPanel certifications={profile.certifications} />
          </aside>
        </div>
      </div>
    </main>
  )
}
