import type { ResumeCertificationViewModel } from "@/lib/resume-types"
import { ResumeSection } from "./resume-section"

type Props = {
  certifications: ResumeCertificationViewModel[]
}

export function CertificationsPanel({ certifications }: Props) {
  if (certifications.length === 0) return null

  return (
    <ResumeSection title="Certifications">
      <div className="space-y-2">
        {certifications.map((cert) => (
          <div
            key={cert.id}
            className="flex items-start justify-between gap-2"
          >
            <div className="min-w-0">
              <p className="text-sm font-medium text-neutral-800 leading-snug">
                {cert.name}
              </p>
              {cert.issuer && (
                <p className="text-xs text-neutral-400">{cert.issuer}</p>
              )}
            </div>
            {cert.year && (
              <span className="shrink-0 text-xs tabular-nums text-neutral-400">
                {cert.year}
              </span>
            )}
          </div>
        ))}
      </div>
    </ResumeSection>
  )
}
