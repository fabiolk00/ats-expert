import type { ResumeSkillGroupViewModel } from "@/lib/resume-types"
import { ResumeSection } from "./resume-section"

type SkillGroupProps = {
  group: ResumeSkillGroupViewModel
}

function SkillGroup({ group }: SkillGroupProps) {
  return (
    <div>
      <p className="mb-1.5 text-[11px] font-semibold text-neutral-400 uppercase tracking-wide">
        {group.category}
      </p>
      <div className="flex flex-wrap gap-1.5">
        {group.skills.map((skill) => (
          <span
            key={skill}
            className="rounded-md border border-neutral-200 bg-neutral-50 px-2 py-0.5 text-xs text-neutral-600"
          >
            {skill}
          </span>
        ))}
      </div>
    </div>
  )
}

type Props = {
  skillGroups: ResumeSkillGroupViewModel[]
}

export function SkillsPanel({ skillGroups }: Props) {
  if (skillGroups.length === 0) return null

  return (
    <ResumeSection title="Skills">
      <div className="space-y-3.5">
        {skillGroups.map((group) => (
          <SkillGroup key={group.id} group={group} />
        ))}
      </div>
    </ResumeSection>
  )
}
