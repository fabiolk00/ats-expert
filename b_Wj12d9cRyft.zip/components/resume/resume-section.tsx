import { cn } from "@/lib/utils"

type Props = {
  title: string
  children: React.ReactNode
  className?: string
  scrollable?: boolean
}

export function ResumeSection({ title, children, className, scrollable }: Props) {
  return (
    <div
      className={cn(
        "flex min-h-0 flex-col rounded-lg border border-neutral-200 bg-white",
        scrollable && "overflow-hidden",
        className
      )}
    >
      <div className="flex items-center border-b border-neutral-100 px-4 py-2.5">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
          {title}
        </span>
      </div>
      <div
        className={cn(
          "flex-1 p-4",
          scrollable && "overflow-y-auto"
        )}
      >
        {children}
      </div>
    </div>
  )
}
