"use client"

import type { ResumeProfileViewModel } from "@/lib/resume-types"
import { Download, Sparkles, MapPin, Mail, Phone, Upload } from "lucide-react"

type Props = {
  profile: ResumeProfileViewModel
  onOpenEnhancement?: () => void
  onDownloadPdf?: () => void
}

export function ResumeProfileHeader({
  profile,
  onOpenEnhancement,
  onDownloadPdf,
}: Props) {
  const { fullName, headline, location, contact } = profile

  const contactItems = [
    contact.email && {
      label: contact.email,
      href: `mailto:${contact.email}`,
      icon: <Mail className="h-3.5 w-3.5" />,
    },
    contact.phone && {
      label: contact.phone,
      href: `tel:${contact.phone}`,
      icon: <Phone className="h-3.5 w-3.5" />,
    },
    contact.linkedin && {
      label: contact.linkedin.replace(/^https?:\/\//, ""),
      href: contact.linkedin.startsWith("http")
        ? contact.linkedin
        : `https://${contact.linkedin}`,
      icon: (
        <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
      ),
    },
    contact.github && {
      label: contact.github.replace(/^https?:\/\//, ""),
      href: contact.github.startsWith("http")
        ? contact.github
        : `https://${contact.github}`,
      icon: (
        <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
        </svg>
      ),
    },
  ].filter(Boolean) as { label: string; href: string; icon: React.ReactNode }[]

  return (
    <header className="mb-5 flex items-start justify-between gap-6">
      {/* Identity block */}
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-3">
          <h1 className="text-xl font-semibold tracking-tight text-neutral-900">
            {fullName}
          </h1>
          {headline && (
            <span className="text-sm font-medium text-neutral-500">
              {headline}
            </span>
          )}
        </div>

        <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
          {location && (
            <span className="flex items-center gap-1 text-xs text-neutral-400">
              <MapPin className="h-3 w-3" />
              {location}
            </span>
          )}
          {contactItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              target={
                item.href.startsWith("mailto") || item.href.startsWith("tel")
                  ? undefined
                  : "_blank"
              }
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs text-neutral-400 transition-colors hover:text-neutral-700"
            >
              {item.icon}
              {item.label}
            </a>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex shrink-0 items-center gap-2">
        <button
          type="button"
          className="flex items-center gap-1.5 rounded-md border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 transition-colors hover:border-neutral-300 hover:bg-neutral-50"
        >
          <Upload className="h-3.5 w-3.5" />
          Importar /
          <svg className="h-3.5 w-3.5 text-[#0A66C2]" viewBox="0 0 24 24" fill="currentColor" aria-label="LinkedIn">
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
          </svg>
          / PDF
        </button>

        <button
          type="button"
          onClick={onDownloadPdf}
          className="flex items-center gap-1.5 rounded-md border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 transition-colors hover:border-neutral-300 hover:bg-neutral-50"
        >
          <Download className="h-3.5 w-3.5" />
          Download PDF
        </button>

        <button
          type="button"
          onClick={onOpenEnhancement}
          className="flex items-center gap-1.5 rounded-md bg-neutral-900 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-neutral-800"
        >
          <Sparkles className="h-3.5 w-3.5" />
          Melhorar currículo com IA
        </button>
      </div>
    </header>
  )
}
