import { ResumeProfilePage } from "@/components/resume/resume-profile-page"
import { mockResumeProfile } from "@/lib/resume-mock"

export default function Page() {
  return <ResumeProfilePage profile={mockResumeProfile} />
}
