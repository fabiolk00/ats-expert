export type ResumeContactViewModel = {
  email?: string
  phone?: string
  linkedin?: string
  github?: string
}

export type ResumeExperienceViewModel = {
  id: string
  title: string
  company: string
  location?: string
  workMode?: string
  startDate: string
  endDate?: string
  current: boolean
  bullets: string[]
}

export type ResumeSkillGroupViewModel = {
  id: string
  category: string
  skills: string[]
}

export type ResumeEducationViewModel = {
  id: string
  degree: string
  institution: string
  year?: string
}

export type ResumeCertificationViewModel = {
  id: string
  name: string
  issuer?: string
  year?: string
}

export type ResumeProfileViewModel = {
  fullName: string
  headline?: string
  location?: string
  contact: ResumeContactViewModel
  summary?: string
  experiences: ResumeExperienceViewModel[]
  skillGroups: ResumeSkillGroupViewModel[]
  education: ResumeEducationViewModel[]
  certifications: ResumeCertificationViewModel[]
}
