import type { ResumeProfileViewModel } from "./resume-types"

export const mockResumeProfile: ResumeProfileViewModel = {
  fullName: "Fábio Kroker",
  headline: "Senior BI Developer",
  location: "Curitiba, Brazil",
  contact: {
    email: "fabio.kroker@email.com",
    phone: "+55 41 99999-9999",
    linkedin: "linkedin.com/in/fabiokroker",
    github: "github.com/fabiokroker",
  },
  summary:
    "Senior BI Developer with 8+ years of experience designing scalable analytics solutions and enterprise dashboards. Specialized in Qlik Sense, Power BI, and cloud data platforms. Proven track record of translating complex business requirements into actionable, reliable data products across manufacturing and financial sectors.",
  experiences: [
    {
      id: "exp-1",
      title: "Senior BI Developer",
      company: "CNH Industrial",
      location: "Curitiba, Brazil",
      workMode: "Hybrid",
      startDate: "Jan 2025",
      endDate: undefined,
      current: true,
      bullets: [
        "Led Qlik Sense to Qlik SaaS migration initiatives across enterprise dashboards, reducing infrastructure costs by 30%.",
        "Improved data model reliability and documentation standards, cutting production incident response time by 40%.",
        "Partnered with data engineering and architecture teams to validate business rules and ensure data quality.",
        "Designed and shipped 12 executive-level dashboards consumed by 200+ stakeholders globally.",
      ],
    },
    {
      id: "exp-2",
      title: "BI Developer",
      company: "Stefanini Group",
      location: "São Paulo, Brazil",
      workMode: "Remote",
      startDate: "Mar 2022",
      endDate: "Dec 2024",
      current: false,
      bullets: [
        "Developed and maintained 30+ Power BI reports for financial and operational use cases.",
        "Built automated ETL pipelines using Azure Data Factory and SQL Server, reducing manual reporting effort by 60%.",
        "Collaborated with business stakeholders to define KPIs and implement data governance practices.",
        "Mentored 2 junior analysts and led internal BI guild sessions on best practices.",
      ],
    },
    {
      id: "exp-3",
      title: "Data Analyst",
      company: "Itaú Unibanco",
      location: "São Paulo, Brazil",
      workMode: "On-site",
      startDate: "Jun 2019",
      endDate: "Feb 2022",
      current: false,
      bullets: [
        "Performed exploratory data analysis on customer transaction data to identify fraud patterns.",
        "Built Python-based dashboards and automated reporting scripts consumed by risk management teams.",
        "Delivered ad-hoc analysis and data models to support product and credit decisions.",
      ],
    },
  ],
  skillGroups: [
    {
      id: "sk-1",
      category: "Business Intelligence",
      skills: ["Qlik Sense", "Qlik Cloud", "Power BI", "Tableau"],
    },
    {
      id: "sk-2",
      category: "Data Engineering",
      skills: ["SQL", "PySpark", "Databricks", "GCP", "Azure Data Factory"],
    },
    {
      id: "sk-3",
      category: "Analytics",
      skills: ["Data Modeling", "ETL Design", "Dashboard Design", "KPI Definition"],
    },
    {
      id: "sk-4",
      category: "Programming",
      skills: ["Python", "DAX", "LookML", "Shell Script"],
    },
  ],
  education: [
    {
      id: "edu-1",
      degree: "B.Sc. Information Systems",
      institution: "PUCPR — Pontifícia Universidade Católica do Paraná",
      year: "2018",
    },
    {
      id: "edu-2",
      degree: "MBA in Data Engineering",
      institution: "FIAP",
      year: "2021",
    },
  ],
  certifications: [
    {
      id: "cert-1",
      name: "Qlik Sense Business Analyst",
      issuer: "Qlik",
      year: "2023",
    },
    {
      id: "cert-2",
      name: "Microsoft PL-300 — Power BI Data Analyst",
      issuer: "Microsoft",
      year: "2022",
    },
    {
      id: "cert-3",
      name: "Google Professional Data Engineer",
      issuer: "Google Cloud",
      year: "2024",
    },
  ],
}
